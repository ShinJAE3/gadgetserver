from django.shortcuts import render
from django.http import HttpResponse
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
UPLOAD_DIR = os.path.join(BASE_DIR, 'adreq/media/upload')
UPLOAD_ADS_DIR = os.path.join(BASE_DIR, 'adreq/media/upload/ads')

#Default Page
def default_page(request):
    return render(request, 'adreq/index.html');

#Valid Check
def valid_check(iid):
    #TODO : valid check with Inventory ID
    #TEST CODE
    if iid == 'invalid':
        return False
    else:
        return True

#Insert info
def db_insert_delivery(iid, ad_type):
    return

#Ad Request
def ad_req(request):
    if not request.GET:
        return render(request, 'adreq/ad_res.html')
    else:
        iid = request.GET['inven']
        ad_type = request.GET['adtype']

    if iid is None and iid == '' or ad_type is None and ad_type == '':
        return render(request, 'adreq/ad_res.html')

    if valid_check(iid) == True:
        #TODO : get req_id & url from DB data

        if iid == 'test':
            req = [{
                'iid':iid,
                'ad_type':ad_type
            }]
            return render(request, 'adreq/req_test.html', {'req':req})

        #dummy data from DB
        db_insert_delivery(iid, ad_type)
        ad_res = [{
            'ad_url':'http://13.124.238.209/testad',
            'req_id':21341,
            'ad_type':'img',
            'inven_id':iid
        }]
        return render(request, 'adreq/ad_res.html', {'ad_res':ad_res})
    else:
        return render(request, 'adreq/ad_res.html')

#Insert info
def db_insert_new_ad(ad_url, ):
    return

#Upload Form
def upload(request):
    return render(request, 'adreq/upload.html');

#Upload
def ad_upload(req):
    if req.method == 'POST':
        if 'file' in req.FILES:
            file = req.FILES['file']
            filename = file._name

            fp = open('%s/%s' % (UPLOAD_ADS_DIR, filename) , 'wb')
            for chunk in file.chunks():
                fp.write(chunk)
            fp.close()
            return HttpResponse('File Uploaded')
    return HttpResponse('Failed to Upload File')

#Image Ad
def test_ad(request):
    image_data = open(UPLOAD_ADS_DIR + "/gadget_icon.png", "rb").read() 
    return HttpResponse(image_data, content_type = 'image/png')

#Ad Impress
def ad_impress(request):
    return HttpResponse('')
