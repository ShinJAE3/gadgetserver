from django.conf.urls import include, url
from adreq import views

urlpatterns = [
    url(r'^$', views.ad_req, name='ad_req'),
]
