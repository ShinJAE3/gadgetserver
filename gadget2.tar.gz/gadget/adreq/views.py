from django.shortcuts import render
from django.http import HttpResponse
from django.utils import timezone
from user_agents import parse
from PIL import Image
from django.db import connection

import random
import os
import uuid

from adreq.models import *

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
UPLOAD_DIR = os.path.join(BASE_DIR, 'adreq/media/upload')
UPLOAD_ADS_DIR = os.path.join(BASE_DIR, 'adreq/media/upload/ads')

#Default Page
def default_page(request):
    return render(request, 'adreq/index.html');

#Valid Check
def valid_check(iid, keystr, app_id):
    if not GADGET_MEDIA.objects.filter(name = app_id):
        return False

    if not GADGET_INVENTORY.objects.filter(name = iid):
    #TODO : valid check for media with inv id
        if GADGET_MEDIA.objects.filter(name = app_id):
            media = GADGET_MEDIA.objects.filter(name=app_id)[0]
            inventory = GADGET_INVENTORY(media_id = media.id, name = iid, type = 1, birth = timezone.now(), status = 1)
            inventory.save()

    if not GADGET_DEVKEYS.objects.filter(key = keystr):
        return False
    else:
        return True

#    if iid == 'invalid':
#        return False
#    else:
#        return True

#Insert info
def db_insert_delivery(request, iid, type):
    ua_string = request.META.get('HTTP_USER_AGENT','')
    user_agent = parse(ua_string)
    if type == 'all' or type == 'ALL' or type == 'All':
        ad = GADGET_ADS.objects.exclude(expired=1).order_by('?')[0]
    if type == 'rect' or type == 'RECT' or type == 'Rect':
        ad = GADGET_ADS.objects.exclude(expired=1).filter(ratio=1).order_by('?')[0]
    if type == 'hori' or type == 'HORI' or type == 'Hori':
        ad = GADGET_ADS.objects.exclude(expired=1).filter(ratio__gt=1).order_by('?')[0]
    if type == 'vert' or type == 'VERT' or type == 'Vert':
        ad = GADGET_ADS.objects.exclude(expired=1).filter(ratio__lt=1).order_by('?')[0]
    image_data = open(ad.url, "rb").read() 

    user = GADGET_USER.objects.first()
    inv = GADGET_INVENTORY.objects.filter(name = iid)[0]
    imp = GADGET_IMPRESS(ad_id = ad.id, inv_id = inv.id, user_id = user.id, t_transfer = timezone.now(), result = 1, language = request.META.get('HTTP_ACCEPT_LANGUAGE',''), ip = request.META.get('REMOTE_ADDR',''), query_string = request.META.get('QUERY_STRING',''), user_agent = ua_string, browser = user_agent.browser, os = user_agent.os, device =user_agent.device)
    imp.save()

    return image_data

#Ad Request
def ad_req(request):
    if not request.GET:
        return render(request, 'adreq/ad_res.html')
    else:
        iid = request.GET['inv']
        key = request.GET['key']
        app = request.GET['app']
        type = request.GET['type']
    image_data = open('/home/ubuntu/workspace/gadget/adreq/media/upload/ads/gadget_icon.png', "rb").read() 

    if iid is None and iid == '' or key is None and key == '' or type is None and type == '':
        return HttpResponse(image_data, content_type = 'image/png')

    if valid_check(iid, key, app) == True:

        return HttpResponse(db_insert_delivery(request, iid, type), content_type = 'image/png')

    else:
        return HttpResponse('Error2')
        return HttpResponse(image_data, content_type = 'image/png')


def get_key():
    return uuid.uuid4()

#Dummy Data Insert
def db_test(request):
    if not GADGET_CORPS.objects.filter(corpname = 'test_corp'):
        corp = GADGET_CORPS(type = 1, category = 1, corpname = 'test_corp', url = 'http://google.com', email = 'test@email.test', addr = 'Test Addr', call_num = '+81012345678', birth = timezone.now())
        corp.save()

    if not GADGET_USER.objects.filter(email = 'naezang@gmail.com'):
        user = GADGET_USER(gender = 1, old = 1, location = 'Seoul', email = 'naezang@gmail.com', url = 'http://facebook.com')
        user.save()

    if not GADGET_ADVERTISER.objects.filter(name = 'test_adv'):
        adv = GADGET_ADVERTISER(corp_id = corp.id, name='test_adv', birth = timezone.now())
        adv.save()

    if not GADGET_MEDIA.objects.filter(name = 'test_media'):
        media = GADGET_MEDIA(corp_id = corp.id, name = 'test_media', type = 1, url = 'http://play.google.com', birth = timezone.now(), status = 1)
        media.save()

    if not GADGET_INVENTORY.objects.filter(name = 'test_inv'):
        inventory = GADGET_INVENTORY(media_id = media.id, name = 'test_inv', type = 1, birth = timezone.now(), status = 1)
        inventory.save()

    #corp = GADGET_CORPS.objects.filter(type=1).latest('birth')
    #corp.category = 2
    #corp.save()
    #return HttpResponse(corp.category)
    #corp = GADGET_CORPS(type = 1, category = 1, corpname = 'GADGET', url = 'http://playgadget.ga', email = 'naezang@gmail.com', addr = 'SEC Seoul Univ RnD Campus', call_num = '+81012345678', birth = timezone.now())
    #corp.save()

    #media = GADGET_MEDIA(corp_id = corp.id, name = 'sh_game', type = 1, url = 'http://play.google.com', birth = timezone.now(), status = 1)
    #media.save()
    #media = GADGET_MEDIA(corp_id = corp.id, name = 'sh_android', type = 1, url = 'http://play.google.com', birth = timezone.now(), status = 1)
    #media.save()
    #media = GADGET_MEDIA(corp_id = corp.id, name = 'jrs_game', type = 1, url = 'http://play.google.com', birth = timezone.now(), status = 1)
    #media.save()
    #media = GADGET_MEDIA(corp_id = corp.id, name = 'kichan_game', type = 1, url = 'http://play.google.com', birth = timezone.now(), status = 1)
    #media.save()
    #corps = GADGET_CORPS.objects.first()
    #keys = get_key()
    #devkey = GADGET_DEVKEYS(corp_id = corps.id, key = keys, birth = timezone.now(), status = 1)
    #devkey.save()

    #return render(request, 'adreq/db_test.html', {'db_test':db_test})
    return HttpResponse('DB INSERT SUCCESS')
    #return HttpResponse(keys)

#Upload Form
def upload(request):
    return render(request, 'adreq/upload.html');

#Upload
def ad_upload(request):
    if request.method == 'POST':
        if 'file' in request.FILES:
            file = request.FILES['file']
            filename = file._name

            fp = open('%s/%s' % (UPLOAD_ADS_DIR, filename) , 'wb')
            for chunk in file.chunks():
                fp.write(chunk)
            fp.close()

            ad_path = ('%s/%s'%(UPLOAD_ADS_DIR, filename))
            adv = GADGET_ADVERTISER.objects.first()

            with Image.open(ad_path) as img:
                w, h = img.size
            r = w/(h*1.0);

            ad = GADGET_ADS(adv_id = adv.id, type = 1, name = 'test_ad', width = w, height = h, ratio = r, url = ad_path, budget = 100000, birth = timezone.now(), expired = False)
            ad.save()

            return HttpResponse('File Uploaded')
    return HttpResponse('Failed to Upload File')

#Image Ad Horizontal
def test_ad_hori(request):
    ua_string = request.META.get('HTTP_USER_AGENT','')
    user_agent = parse(ua_string)
    ad = GADGET_ADS.objects.filter(ratio__gt=1).order_by('?')[0]
    image_data = open(ad.url, "rb").read() 

    inv = GADGET_INVENTORY.objects.first()
    user = GADGET_USER.objects.first()

    imp = GADGET_IMPRESS(ad_id = ad.id, inv_id = inv.id, user_id = user.id, t_transfer = timezone.now(), result = 1, language = request.META.get('HTTP_ACCEPT_LANGUAGE',''), ip = request.META.get('REMOTE_ADDR',''), query_string = request.META.get('QUERY_STRING',''), user_agent = ua_string, browser = user_agent.browser, os = user_agent.os, device =user_agent.device)
    imp.save()

    return HttpResponse(image_data, content_type = 'image/png')

#Image Ad Vertical test
def test_ad_vert(request):
    ua_string = request.META.get('HTTP_USER_AGENT','')
    user_agent = parse(ua_string)
    ad = GADGET_ADS.objects.filter(ratio__lt=1).order_by('?')[0]
    image_data = open(ad.url, "rb").read() 

    inv = GADGET_INVENTORY.objects.first()
    user = GADGET_USER.objects.first()

    imp = GADGET_IMPRESS(ad_id = ad.id, inv_id = inv.id, user_id = user.id, t_transfer = timezone.now(), result = 1, language = request.META.get('HTTP_ACCEPT_LANGUAGE',''), ip = request.META.get('REMOTE_ADDR',''), query_string = request.META.get('QUERY_STRING',''), user_agent = ua_string, browser = user_agent.browser, os = user_agent.os, device =user_agent.device)
    imp.save()

    return HttpResponse(image_data, content_type = 'image/png')

#Image Ad Vertical test1
def test_ad_vert1(request):
    ua_string = request.META.get('HTTP_USER_AGENT','')
    user_agent = parse(ua_string)
    ad = GADGET_ADS.objects.get(pk=10)
    image_data = open(ad.url, "rb").read() 

    inv = GADGET_INVENTORY.objects.first()
    user = GADGET_USER.objects.first()

    imp = GADGET_IMPRESS(ad_id = ad.id, inv_id = inv.id, user_id = user.id, t_transfer = timezone.now(), result = 1, language = request.META.get('HTTP_ACCEPT_LANGUAGE',''), ip = request.META.get('REMOTE_ADDR',''), query_string = request.META.get('QUERY_STRING',''), user_agent = ua_string, browser = user_agent.browser, os = user_agent.os, device =user_agent.device)
    imp.save()

    return HttpResponse(image_data, content_type = 'image/png')

#Image Ad Vertical test2
def test_ad_vert2(request):
    ua_string = request.META.get('HTTP_USER_AGENT','')
    user_agent = parse(ua_string)
    ad = GADGET_ADS.objects.get(pk=13)
    image_data = open(ad.url, "rb").read() 

    inv = GADGET_INVENTORY.objects.first()
    user = GADGET_USER.objects.first()

    imp = GADGET_IMPRESS(ad_id = ad.id, inv_id = inv.id, user_id = user.id, t_transfer = timezone.now(), result = 1, language = request.META.get('HTTP_ACCEPT_LANGUAGE',''), ip = request.META.get('REMOTE_ADDR',''), query_string = request.META.get('QUERY_STRING',''), user_agent = ua_string, browser = user_agent.browser, os = user_agent.os, device =user_agent.device)
    imp.save()

    return HttpResponse(image_data, content_type = 'image/png')

#Image Ad Gadget Logo
def test_ad(request):
    ua_string = request.META.get('HTTP_USER_AGENT','')
    user_agent = parse(ua_string)
    ad = GADGET_ADS.objects.exclude(expired=1).order_by('?')[0]
    image_data = open(ad.url, "rb").read() 

    inv = GADGET_INVENTORY.objects.first()
    user = GADGET_USER.objects.first()

    imp = GADGET_IMPRESS(ad_id = ad.id, inv_id = inv.id, user_id = user.id, t_transfer = timezone.now(), result = 1, language = request.META.get('HTTP_ACCEPT_LANGUAGE',''), ip = request.META.get('REMOTE_ADDR',''), query_string = request.META.get('QUERY_STRING',''), user_agent = ua_string, browser = user_agent.browser, os = user_agent.os, device =user_agent.device)
    imp.save()

    return HttpResponse(image_data, content_type = 'image/png')

#Ad Impress
def ad_impress(request):
    if not request.GET:
        return HttpResponse('Impression Failed : invalid request METHOD')
    else:
        iid = request.GET['inv']
        app = request.GET['app']

    ip = request.META.get('REMOTE_ADDR','')
    media = GADGET_MEDIA.objects.filter(name=app)[0]
    if media:
        inv = GADGET_INVENTORY.objects.filter(media_id = media.id)
        if not inv:
            return HttpResponse('Impression Failed : invalid inventory')
        else:
            for i in inv:
                if i.name == iid:
                    imp = GADGET_IMPRESS.objects.filter(inv_id=i.id).latest('t_transfer')
                    if imp.ip == ip:
                        imp.result = 2
                        imp.t_impress = timezone.now()
                        imp.save()
                        return HttpResponse('Impression Success')
                    else:
                        return HttpResponse('Impression Failed : invalid IP')

    return HttpResponse('Impression Failed : invalid request')
