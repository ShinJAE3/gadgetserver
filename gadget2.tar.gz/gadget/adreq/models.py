from django.db import models
from django.utils import timezone

class GADGET_CORPS(models.Model):
    type = models.IntegerField(null = True)
    category = models.IntegerField(null = True)
    corpname = models.CharField(max_length = 128)
    url = models.TextField()
    email = models.CharField(max_length = 128)
    addr = models.TextField()
    call_num = models.CharField(max_length = 128)
    birth = models.DateTimeField(default=timezone.now)

    def __unicode__(self):
        return self.id

class GADGET_USER(models.Model):
    gender = models.IntegerField(null = True)
    old = models.IntegerField(null = True)
    location = models.CharField(max_length = 128, null = True)
    email = models.CharField(max_length = 128)
    url = models.TextField()

    def __unicode__(self):
        return self.id

class GADGET_ACCOUNT(models.Model):
    corp = models.ForeignKey('GADGET_CORPS', blank = True, null = True)
    name = models.CharField(max_length = 128)
    type = models.IntegerField(null = True)
    birth = models.DateTimeField(default=timezone.now)
    death = models.DateTimeField(blank=True, null=True)
    status = models.IntegerField(null = True)

    def __unicode__(self):
        return self.id

class GADGET_ADVERTISER(models.Model):
    corp = models.ForeignKey('GADGET_CORPS', blank = True, null = True)
    name = models.CharField(max_length = 128)
    birth = models.DateTimeField(default=timezone.now)

    def __unicode__(self):
        return self.id

class GADGET_ADS(models.Model):
    name = models.CharField(max_length = 128)
    adv = models.ForeignKey('GADGET_ADVERTISER', blank = True, null = True)
    type = models.IntegerField(null = True)
    width = models.CharField(max_length = 10)
    height = models.CharField(max_length = 10)
    ratio = models.DecimalField(max_digits = 5, decimal_places = 3)
    url = models.TextField()
    budget = models.DecimalField(max_digits = 16, decimal_places = 2)
    birth = models.DateTimeField(default = timezone.now)
    death = models.DateTimeField(blank = True, null = True)
    expired = models.BooleanField()

    def __unicode__(self):
        return self.id

class GADGET_MEDIA(models.Model):
    corp = models.ForeignKey('GADGET_CORPS', blank = True, null = True)
    name = models.CharField(max_length = 128)
    type = models.IntegerField(null = True)
    url = models.TextField()
    birth = models.DateTimeField(default=timezone.now)
    death = models.DateTimeField(blank=True, null=True)
    status = models.IntegerField(null = True)

    def __unicode__(self):
        return self.id

class GADGET_TRANSACTION(models.Model):
    acc = models.ForeignKey('GADGET_ACCOUNT', blank = True, null = True)
    type = models.IntegerField(null = True)
    cost = models.DecimalField(max_digits = 16, decimal_places = 2)
    birth = models.DateTimeField(default=timezone.now)
    death = models.DateTimeField(blank=True, null=True)
    status = models.IntegerField(null = True)

    def __unicode__(self):
        return self.id

class GADGET_INVENTORY(models.Model):
    media = models.ForeignKey('GADGET_MEDIA', blank = True, null = True)
    name = models.CharField(max_length = 128)
    type = models.IntegerField(null = True)
    birth = models.DateTimeField(default=timezone.now)
    death = models.DateTimeField(blank=True, null=True)
    status = models.IntegerField(null = True)

    def __unicode__(self):
        return self.id

class GADGET_IMPRESS(models.Model):
    ad = models.ForeignKey('GADGET_ADS', blank = True, null = True)
    inv = models.ForeignKey('GADGET_INVENTORY', blank = True, null = True)
    user = models.ForeignKey('GADGET_USER', blank = True, null = True)
    language = models.CharField(max_length = 128, null = True)
    user_agent = models.TextField()
    ip = models.CharField(max_length = 128, null = True)
    browser = models.CharField(max_length = 128, null = True)
    os = models.CharField(max_length = 128, null = True)
    device = models.CharField(max_length = 128, null = True)
    query_string = models.CharField(max_length = 128, null = True)
    t_transfer = models.DateTimeField(blank=True, null=True)
    t_impress = models.DateTimeField(blank=True, null=True)
    result = models.IntegerField(null = True)

    def __unicode__(self):
        return self.id

class GADGET_DEVKEYS(models.Model):
    corp = models.ForeignKey('GADGET_CORPS', blank = True, null = True)
    key = models.CharField(max_length = 40)
    birth = models.DateTimeField(default=timezone.now)
    death = models.DateTimeField(blank=True, null=True)
    status = models.IntegerField(null = True)

    def __unicode__(self):
        return self.id

class GADGET_CLABFAIR(models.Model):
    name = models.CharField(max_length = 128)
    url = models.TextField()
    birth = models.DateTimeField(default=timezone.now)
    status = models.IntegerField(null = True)

    def __unicode__(self):
        return self.id

# Create your models here.
